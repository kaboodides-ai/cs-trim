מדריך התקנה מהיר - CS Trim ל-Adobe Premiere Pro
=====================================================

תוסף לחיתוך שקט אוטומטי וכתוביות AI מהירות בפרמייר פרו.

אפשרות 1: התקנה אוטומטית (מומלץ)
----------------------------------
משתמשי Mac:
1. לחצו לחיצה כפולה על הקובץ "Install_Mac.command".
2. אם מופיעה התרעת אבטחה, לחצו קליק ימני > Open (פתח).
3. פתחו את Premiere Pro ובחרו בתפריט: Window > Extensions > CS Trim.

משתמשי Windows:
1. לחצו לחיצה כפולה על הקובץ "Install_Windows.bat".
2. פתחו את Premiere Pro ובחרו בתפריט: Window > Extensions > CS Trim.

אפשרות 2: התקנה ידנית
----------------------------------
העתיקו את התיקייה "com.autocut.panel" למיקום הבא במחשב שלכם:

ב-Mac:
~/Library/Application Support/Adobe/CEP/extensions/

ב-Windows:
C:\Users\<שם_המשתמש>\AppData\Roaming\Adobe\CEP\extensions\

*הערה: כדי שפרמייר יטען הרחבות, יש לוודא שמופעל PlayerDebugMode בגרסאות CSXS.
הסקריפטים האוטומטיים מבצעים זאת בלחיצה אחת!

חיבור מפתח Groq AI חינם לכתוביות:
1. כנסו לאתר https://console.groq.com/keys
2. צרו משתמש חינם והפיקו API Key בתוך 10 שניות.
3. הדביקו אותו בלשונית 'כתוביות AI' בתוסף - וזהו!

תהנו מחסכון של שעות עבודה!
