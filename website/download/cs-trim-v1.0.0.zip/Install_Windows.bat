@echo off
chcp 65001 >nul
echo =================================================
echo    מתקין את CS Trim עבור Adobe Premiere Pro
echo =================================================

set "TARGET_DIR=%APPDATA%\Adobe\CEP\extensions\com.autocut.panel"
set "SCRIPT_DIR=%~dp0"
set "PLUGIN_SRC=%SCRIPT_DIR%com.autocut.panel"

if not exist "%PLUGIN_SRC%" (
    echo שגיאה: תיקיית com.autocut.panel לא נמצאה.
    pause
    exit /b 1
)

echo יוצר תיקייה ומעתיק קבצים...
if not exist "%APPDATA%\Adobe\CEP\extensions" mkdir "%APPDATA%\Adobe\CEP\extensions"
if exist "%TARGET_DIR%" rmdir /s /q "%TARGET_DIR%"
xcopy /E /I /Y "%PLUGIN_SRC%" "%TARGET_DIR%" >nul

echo מגדיר הרשאות PlayerDebugMode ב-Registry...
for %%v in (7 8 9 10 11 12 13 14 15 16 17 18 19 20) do (
    reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
    reg add "HKEY_LOCAL_MACHINE\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
)

echo.
echo =================================================
echo  ההתקנה הושלמה בהצלחה!
echo  כעת פתח את Premiere Pro והיכנס ל:
echo  Window ^> Extensions ^> CS Trim
echo =================================================
pause
