#!/bin/bash
# CS Trim - התקנה אוטומטית למשתמשי Mac
echo "================================================="
echo "   מתקין את CS Trim עבור Adobe Premiere Pro   "
echo "================================================="

TARGET_DIR="$HOME/Library/Application Support/Adobe/CEP/extensions"
mkdir -p "$TARGET_DIR"

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PLUGIN_SRC="$SCRIPT_DIR/com.autocut.panel"

if [ ! -d "$PLUGIN_SRC" ]; then
    echo "שגיאה: תיקיית com.autocut.panel לא נמצאה באותו מיקום של הסקריפט."
    exit 1
fi

echo "מעתיק קבצים לתיקיית ההרחבות..."
rm -rf "$TARGET_DIR/com.autocut.panel"
cp -R "$PLUGIN_SRC" "$TARGET_DIR/"

echo "מגדיר הרשאות פיתוח עבור Adobe CEP (PlayerDebugMode)..."
for v in 7 8 9 10 11 12 13 14 15 16; do
    defaults write com.adobe.CSXS.$v PlayerDebugMode 1 2>/dev/null
done

echo ""
echo "================================================="
echo " ✅ ההתקנה הושלמה בהצלחה! "
echo " כעת פתח את Premiere Pro והיכנס ל:"
echo " Window > Extensions > CS Trim"
echo "================================================="
read -p "לחץ Enter לסגירת החלון..."
