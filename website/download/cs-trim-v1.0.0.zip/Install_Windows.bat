@echo off
chcp 65001 >nul
echo =================================================
echo    מתקין את CS Trim עבור Adobe Premiere Pro
echo =================================================

set "TARGET_DIR=%APPDATA%\Adobe\CEP\extensions\com.autocut.panel"
set "SCRIPT_DIR=%~dp0"
set "PLUGIN_SRC=%SCRIPT_DIR%com.autocut.panel"

if not exist "%PLUGIN_SRC%" (
    echo שגיאה: תיקיית com.autocut.panel לא נמצאה.
    pause
    exit /b 1
)

echo יוצר תיקייה ומעתיק קבצים...
if not exist "%APPDATA%\Adobe\CEP\extensions" mkdir "%APPDATA%\Adobe\CEP\extensions"
if exist "%TARGET_DIR%" rmdir /s /q "%TARGET_DIR%"
xcopy /E /I /Y "%PLUGIN_SRC%" "%TARGET_DIR%" >nul

echo מגדיר הרשאות PlayerDebugMode ב-Registry...
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.9" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.13" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.14" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.15" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.16" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1

echo.
echo =================================================
echo  ההתקנה הושלמה בהצלחה!
echo  כעת פתח את Premiere Pro והיכנס ל:
echo  Window ^> Extensions ^> CS Trim
echo =================================================
pause
