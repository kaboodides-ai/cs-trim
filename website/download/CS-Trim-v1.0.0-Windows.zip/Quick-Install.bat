@echo off
chcp 65001 >nul
echo ========================================================
echo       CS Trim - Adobe Premiere Pro Extension Installer
echo ========================================================
echo.

set "TARGET=%APPDATA%\Adobe\CEP\extensions\com.autocut.panel"

echo [1/2] Installing CS Trim to Adobe CEP extensions folder...
if not exist "%APPDATA%\Adobe\CEP\extensions" mkdir "%APPDATA%\Adobe\CEP\extensions"
if exist "%TARGET%" rmdir /s /q "%TARGET%"
mkdir "%TARGET%"

if exist "com.autocut.panel" (
    xcopy /e /i /y /q "com.autocut.panel\*" "%TARGET%\" >nul
) else (
    xcopy /e /i /y /q "bin" "%TARGET%\bin\" >nul
    xcopy /e /i /y /q "CSXS" "%TARGET%\CSXS\" >nul
    xcopy /e /i /y /q "css" "%TARGET%\css\" >nul
    xcopy /e /i /y /q "host" "%TARGET%\host\" >nul
    xcopy /e /i /y /q "img" "%TARGET%\img\" >nul
    xcopy /e /i /y /q "js" "%TARGET%\js\" >nul
    copy /y "index.html" "%TARGET%\" >nul
    copy /y ".debug" "%TARGET%\" >nul
)

echo [2/2] Configuring CSXS PlayerDebugMode in Windows Registry...
for %%v in (7 8 9 10 11 12 13 14 15 16 17 18 19 20) do (
    reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
    reg add "HKLM\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
)

echo.
echo ========================================================
echo [V] Installation completed successfully!
echo.
echo Now open or restart Adobe Premiere Pro:
echo Window ^> Extensions ^> CS Trim
echo ========================================================
echo.
pause
