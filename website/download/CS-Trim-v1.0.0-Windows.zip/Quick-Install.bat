@echo off
chcp 65001 >nul
title התקנת תוסף CS Trim עבור Adobe Premiere Pro
cls
echo ================================================================
echo           ברוכים הבאים להתקנת CS Trim ל-Premiere Pro
echo ================================================================
echo.

set "TARGET=%APPDATA%\Adobe\CEP\extensions\com.autocut.panel"

echo [1/2] מתקין את קבצי התוסף בתיקיית ההרחבות של אדובי...
if not exist "%APPDATA%\Adobe\CEP\extensions" mkdir "%APPDATA%\Adobe\CEP\extensions"
if exist "%TARGET%" rmdir /s /q "%TARGET%"
mkdir "%TARGET%"

if exist "com.autocut.panel" (
    xcopy /e /i /y /q "com.autocut.panel\*" "%TARGET%\" >nul
) else (
    xcopy /e /i /y /q "bin" "%TARGET%\bin\" >nul
    xcopy /e /i /y /q "CSXS" "%TARGET%\CSXS\" >nul
    xcopy /e /i /y /q "css" "%TARGET%\css\" >nul
    xcopy /e /i /y /q "host" "%TARGET%\host\" >nul
    xcopy /e /i /y /q "img" "%TARGET%\img\" >nul
    xcopy /e /i /y /q "js" "%TARGET%\js\" >nul
    copy /y "index.html" "%TARGET%\" >nul
    copy /y ".debug" "%TARGET%\" >nul
)

if exist "%COMMONPROGRAMFILES(x86)%\Adobe\CEP\extensions\com.autocut.panel" (
    rmdir /s /q "%COMMONPROGRAMFILES(x86)%\Adobe\CEP\extensions\com.autocut.panel" >nul 2>&1
)
if exist "%COMMONPROGRAMFILES%\Adobe\CEP\extensions\com.autocut.panel" (
    rmdir /s /q "%COMMONPROGRAMFILES%\Adobe\CEP\extensions\com.autocut.panel" >nul 2>&1
)
if exist "%LOCALAPPDATA%\Temp\cep_cache" rmdir /s /q "%LOCALAPPDATA%\Temp\cep_cache" >nul 2>&1
if exist "%APPDATA%\Adobe\CEP\cache" rmdir /s /q "%APPDATA%\Adobe\CEP\cache" >nul 2>&1

echo [2/2] מפעיל תאימות תוספים ב-Premiere Pro...
for %%v in (7 8 9 10 11 12 13 14 15 16 17 18 19 20) do (
    reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
    reg add "HKLM\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
)

echo.
echo ================================================================
echo  [V] איזה כיף! ההתקנה הושלמה בהצלחה!
echo.
echo  איך פותחים את התוסף בפרמייר:
echo  1. פתחו (או הפעילו מחדש) את Adobe Premiere Pro
echo  2. בתפריט העליון בחרו: Window ^> Extensions ^> CS Trim
echo     (בעברית: חלון ^> הרחבות ^> CS Trim)
echo ================================================================
echo.
echo לחצו על מקש כלשהו לסיום...
pause >nul
